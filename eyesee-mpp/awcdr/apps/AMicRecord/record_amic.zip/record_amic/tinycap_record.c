/* tinycap.c
**
** Copyright 2011, The Android Open Source Project
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**     * Redistributions of source code must retain the above copyright
**       notice, this list of conditions and the following disclaimer.
**     * Redistributions in binary form must reproduce the above copyright
**       notice, this list of conditions and the following disclaimer in the
**       documentation and/or other materials provided with the distribution.
**     * Neither the name of The Android Open Source Project nor the names of
**       its contributors may be used to endorse or promote products derived
**       from this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY The Android Open Source Project ``AS IS'' AND
** ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL The Android Open Source Project BE LIABLE
** FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
** OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGE.
*/

#include <tinyalsa/asoundlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <signal.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include <math.h>
#include "preproc_for_QuanZhi_simplify.h"

#define FORMAT_PCM 1
#define IN_BIT 32
#define IN_RATA 32000
#define OUT_BIT 16
#define OUT_RATA 16000
FILE *file;
unsigned int card = 1;
unsigned int device = 0;
unsigned int channels = 2;
unsigned int rate = 16000;
unsigned int bits = 16;
unsigned int frames;
unsigned int period_size = 1024;
unsigned int period_count = 4;
unsigned int capture_time = UINT_MAX;
enum pcm_format format;
int run_over=1;

enum { kSamplesPerFrame = 320 };
enum { koutSamplesPerFrame = 160 };

pthread_t recordpthread,sendpthread;
struct queue {
	int	size;
	int	readp;
	int	writep;
	pthread_mutex_t	mutex;
	pthread_cond_t empty;
	pthread_cond_t full;
	char *data;
};
struct queue *data_queue;
struct queue *queue_init(int size)
{
	struct queue *queue = malloc(sizeof(struct queue));

	if(queue == NULL)
		printf("Out of memory in queue_init\n");

	queue->data = malloc(sizeof(char) * (size));
	if(queue->data == NULL)
		printf("Out of memory in queue_init\n");

	queue->size = size;
	queue->readp = queue->writep = 0;
	pthread_mutex_init(&queue->mutex, NULL);
	pthread_cond_init(&queue->empty, NULL);
	pthread_cond_init(&queue->full, NULL);

	return queue;
}


void queue_put(struct queue *queue, void *data)
{
	int nextp;

	pthread_mutex_lock(&queue->mutex);

	while((nextp = (queue->writep + 160*channels*2) % queue->size) == queue->readp)
	{
		pthread_cond_wait(&queue->full, &queue->mutex);
	}
	//printf("1 %d,%d,%d\n",nextp,queue->writep,queue->readp);
	//queue->data[queue->writep] = data;
	memcpy(&queue->data[queue->writep],data,160*channels*2);
	queue->writep = nextp;
	pthread_cond_signal(&queue->empty);
	pthread_mutex_unlock(&queue->mutex);
}


void *queue_get(struct queue *queue)
{
	void *data;
	pthread_mutex_lock(&queue->mutex);

	while(queue->readp == queue->writep)
	{
		pthread_cond_wait(&queue->empty, &queue->mutex);
	}
	//printf("2 %d,%d\n",queue->writep,queue->readp);
	//data = queue->data[queue->readp];
	data = &queue->data[queue->readp];
	queue->readp = (queue->readp + 160*channels*2) % queue->size;
	pthread_cond_signal(&queue->full);
	pthread_mutex_unlock(&queue->mutex);

	return data;
}
#define ACOEFF 0.9998779297 //0.9997558594 //0.99951171875f
#if 0
void r6_stereo_preproc(int32_t* aint, int16_t* ashort, uint32_t N) {
    static float xHist1 = 0,xHist2=0;
    static float yHist1 = 0,yHist2=0;
    int32_t tmp_int1,tmp_int2;

    float sum;
    uint32_t i;
    float ftmp;

    for (i = 0; i < N; i+=2) {
        tmp_int1 = (aint[i]) >> 6;  tmp_int2 = (aint[i+1]) >> 6;
#if 1
        ftmp = (float)tmp_int1;
        sum = ftmp - xHist1;
        sum = sum + ACOEFF * yHist1;
        tmp_int1 = (int32_t)sum;
        yHist1 = sum;
        xHist1 = ftmp;

        ftmp = (float)tmp_int2;
        sum = ftmp - xHist2;
        sum = sum + ACOEFF * yHist2;
        tmp_int2 = (int32_t)sum;
        yHist2 = sum;
        xHist2 = ftmp;
#endif
        ashort[i] = (int16_t)tmp_int1; ashort[i+1] = (int16_t)tmp_int2;
        aint[i] = tmp_int1;  aint[i+1] = tmp_int2;
    }
}


void r6_mono_preproc(int32_t* aint, int16_t* ashort, uint32_t N) {
    static float xHist = 0;
    static float yHist = 0;
    float sum;
    uint32_t i;
    int32_t tmp_int;
    float ftmp;
    for (i = 0; i < N; i++) {
        tmp_int = (aint[i]) >> 6;
#if 1
        ftmp = (float)tmp_int;
        sum = ftmp - xHist;
        sum = sum + ACOEFF * yHist;
        tmp_int = (int32_t)sum;
        yHist = sum;
        xHist = ftmp;
#endif
        ashort[i] = (int16_t)tmp_int;
        aint[i] = tmp_int;
    }
}
#endif

int capturing = 1;
int prinfo = 1;
void sigint_handler(int sig)
{
    if (sig == SIGINT){
        capturing = 0;
    }
}

void *record(void *arg)
{
    struct pcm_config config;
    struct pcm *pcm;
    char *buffer;
    unsigned int size;
    unsigned int frames_read;
    unsigned int total_frames_read;
    unsigned int bytes_per_frame;
    int index;
    struct timeval tv1,tv2;
    int cur_time,last_time;
    int max_time=0,use_time;
    int run_time=0;
    int16_t* ns_buffer = NULL;
    int test=1;
    int i;

    memset(&config, 0, sizeof(config));
    config.channels = channels;
    config.rate = rate;
    config.period_size = period_size;
    config.period_count = period_count;
    config.format = format;
    config.start_threshold = 0;
    config.stop_threshold = 0;
    config.silence_threshold = 0;

    pcm = pcm_open(card, device, PCM_IN, &config);
    if (!pcm || !pcm_is_ready(pcm)) {
        fprintf(stderr, "Unable to open PCM device (%s)\n",
                pcm_get_error(pcm));
        return 0;
    }

    //size = pcm_frames_to_bytes(pcm, pcm_get_buffer_size(pcm));
    size = kSamplesPerFrame * channels * sizeof(int32_t);
    buffer = malloc(size);

    if (!buffer) {
        fprintf(stderr, "Unable to allocate %u bytes\n", size);
        pcm_close(pcm);
        return 0;
    }

    size = koutSamplesPerFrame * channels * sizeof(int16_t);
    ns_buffer = malloc(size);//32bit to 16bit buffer
    if (!ns_buffer) {
        fprintf(stderr, "Unable to allocate %u bytes\n", size);
        return 0;
    }

    if (prinfo) {
        printf("Capturing sample: %u ch, %u hz, %u bit\n", channels, rate,
           pcm_format_to_bits(format));
    }


    /*void *hdl = r6_stereo_init(IN_BIT,IN_RATA,channels,OUT_BIT,OUT_RATA,channels,kSamplesPerFrame*4*2);
    uint32_t lenshort = get_output_data_len(hdl);
    printf("the get out data len is:%d\n",lenshort);*/

    bytes_per_frame = pcm_frames_to_bytes(pcm, 1);
    total_frames_read = 0;
    frames_read = 0;
    printf("the size is:%d\n",data_queue->size);
    while (capturing) {
        frames_read = pcm_readi(pcm, ns_buffer, 160);
        total_frames_read += frames_read;
        if ((total_frames_read / rate) >= capture_time) {
            capturing = 0;
        }
	/*if (fwrite(buffer, 1, 320*channels*4, file) == 0) {
                fprintf(stderr,"Error capturing sample\n");
                break;
        }*/
	//r6_stereo_preproc(hdl,(int32_t*)buffer,ns_buffer);
	queue_put(data_queue, ns_buffer);
    }
    //r6_stereo_uninit(hdl);
    free(buffer);
    free(ns_buffer);
    pcm_close(pcm);
    fclose(file);
    run_over=0;
}

void *nfsdata(void *arg)
{
    int test1=1;
    int i;
    char *send_buf;
    while(1)
    {
	    send_buf=queue_get(data_queue);
	    if (fwrite(send_buf, 1, 160*channels*2, file) < 0) {
                fprintf(stderr,"Error capturing sample\n");
                break;
        }	
    }
}

int main(int argc, char **argv)
{
    int all_buffers_size=32000*2*3*5*2;

    if (argc < 2) {
        fprintf(stderr, "Usage: %s {file.wav | --} [-D card] [-d device] [-c channels] "
                "[-r rate] [-b bits] [-p period_size] [-n n_periods] [-t time_in_seconds]\n\n"
                "Use -- for filename to send raw PCM to stdout\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1],"--") == 0) {
        file = stdout;
        prinfo = 0;
    } else {
        file = fopen(argv[1], "wb");
        if (!file) {
            fprintf(stderr, "Unable to create file '%s'\n", argv[1]);
            return 1;
        }
    }

    //format = PCM_FORMAT_S24_LE;


    /* install signal handler and begin capturing */
    signal(SIGINT, sigint_handler);
    
    data_queue = queue_init(all_buffers_size);
    pthread_create(&recordpthread, NULL, record, NULL);
    pthread_create(&sendpthread, NULL, nfsdata, NULL);
 

    pthread_join(recordpthread,NULL);
    pthread_join(sendpthread,NULL); 
    return 0;
}
